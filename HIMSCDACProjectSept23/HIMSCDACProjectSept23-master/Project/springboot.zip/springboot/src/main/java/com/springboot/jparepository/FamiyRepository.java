package com.springboot.jparepository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.springboot.model.FamilyPolicy;

public interface FamiyRepository extends JpaRepository<FamilyPolicy, Long>{

}
