package com.springboot.jparepository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.springboot.model.IndividualPolicy;

public interface IndividualPolicyRepository extends JpaRepository<IndividualPolicy, Long> {

	

	
	

}



